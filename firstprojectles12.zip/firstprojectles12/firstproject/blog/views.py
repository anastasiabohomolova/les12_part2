from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse, HttpResponseRedirect
from blog.models import Post
from blog.forms import PostForm

def post_list(request):
    return HttpResponse('<h1>post_list</h1>')

def post_create(request):
    pass
    # form = PostForm(request.POST)
    #
    # if form.is_valid():
    #     instance = form.save(commit=False)
    #     instance.save()
    #     return HttpResponseRedirect(instance.get_absolute_url())
    #
    # context = {
    #     'title': 'Post create',
    #     'form': form
    # }
    #
    # return render(request, 'post_detail.html', context)

def post_delete(request):
    return HttpResponse('<h1>post_delete</h1>')

def post_update(request):
    return HttpResponse('<h1>post_update</h1>')

def home_page(request):
    return HttpResponse('<h1>home_page</h1>')

def post_detail(request, id=None):
    pass
    # instance = Post.objects.all(Post, id)
    # context = {
    #     'title': 'Post detail',
    #     'object_list': instance
    # }
    #
    # return render(request, 'post_detail.html', context)

